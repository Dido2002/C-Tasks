﻿using System;
using System.Linq;
using System.Xml.Linq;

namespace ArraysEx02
{
	internal class Program
	{
		static void Main(string[] args)
		{
			//2.Common Elements

			//Create a program that prints out all common elements in two arrays.
			//You have to compare the elements of the second array to the elements of the first.

			string[] arr1 = Console.ReadLine().Split(',');
			string[] arr2 = Console.ReadLine().Split(',');

			for (int i = 0; i < arr1.Length; i++)
			{
				for (int p = 0; p < arr2.Length; p++)
				{
					if (arr1[i] == arr2[p]/* && arr1[i] != null && arr2[i] != null*/)
					{
						Console.Write(arr1[i] + " ");
					}
				}
			}
		}
	}
}
