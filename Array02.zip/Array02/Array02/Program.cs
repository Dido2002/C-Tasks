﻿using System;

namespace Array02
{
	internal class Program
	{
		static void Main(string[] args)
		{
			Console.WriteLine("How many numbers you want?");
			int number = int.Parse(Console.ReadLine());
			int[] numbers = new int[number];
			// First we enter how many numbers we want to add in the array then we store them in the array
			for (int i = 0; i < number; i++)
			{
			//Then we make a loop to add numbers 
				int n = int.Parse(Console.ReadLine());
				numbers[i] = n;

			}
			//This loop is to output the numbers in reverse order

			for (int i = numbers.Length - 1; i >= 0; i--)
			{
				Console.WriteLine(numbers[i] + " ");
			}	

		}
	}
}
