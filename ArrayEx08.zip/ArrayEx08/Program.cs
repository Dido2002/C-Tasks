﻿using System;
using System.Linq;
using System.Xml;

namespace ArrayEx08
{
	internal class Program
	{
		static void Main(string[] args)
		{
			//8.Magic Sum
			//Create a program, which prints all unique pairs in an array of integers whose sum is equal to a given number.


			//First we create an array to store the elements
			int[] array = Console.ReadLine().Split(',').Select(int.Parse).ToArray();
			int randomNum = int.Parse(Console.ReadLine());


			//We enter the array with for loop
			for (int i = 0; i < array.Length; i++)
			{
				//Another loop to check if two indexes are equal to the randomNum
				for (int j = i + 1; j < array.Length; j++)
				{
					if (array[i] + array[j] == randomNum)
					{
						Console.WriteLine("The numbers which sum is qual to the random numbers are: " + array[i] + " + " + array[j]);
					}
				}
			}
		}
	}
}
