﻿using System;
using System.Linq;
using System.Xml.Linq;

namespace ArrayEx05
{
	internal class Program
	{
		static void Main(string[] args)
		{
			//5.Top Integers

			//Create a program to find all the top integers in an array.
			//A top integer is an integer that is greater than all the elements to its right.


			//First we create an array to store the inputs
			int[] array = Console.ReadLine().Split(',').Select(int.Parse).ToArray();


			//Then we add for loop to enter in the array and to pass through it
			for (int i = 0; i < array.Length; i++)
			{

				//Create a variable to check if the next number is bigger
				bool thisNumIsBigger = true;

				//With this for loop we 
				for (int j = i + 1; j < array.Length; j++)
				{

					//Check if the current element is bigger
					if (array[i] <= array[j])
					{
						thisNumIsBigger = false;
					}
				}
				if (thisNumIsBigger) 
				{
					Console.Write(array[i] + " ");
				}
			}
	
		}
	}
}
