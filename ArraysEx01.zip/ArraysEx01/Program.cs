﻿using System;
using System.Linq;
using static System.Net.Mime.MediaTypeNames;

namespace ArraysEx01
{
	internal class Program
	{
		static void Main(string[] args)
		{
			//1.Train

			//A train has an **n * *number of wagons(integer, received as input).
			//On the next n lines, you will receive the number of people that are going
			//to get on each wagon.Print out the number of passengers in each wagon followed
			//by the total number of passengers on the train.

			int wagons = int.Parse(Console.ReadLine());
			int[] array = new int[wagons];

			//First we input the number of the wagons and create array to store the numbers of passagers in each wagon

			for (int i = 0; i < wagons; i++)
			{
			//Then we enter the number of passagers in each wagon
				int passagersCount = int.Parse(Console.ReadLine());
				array[i] += passagersCount;
			}
			//Execute
			Console.WriteLine($"There are: {wagons} wagons");
			Console.WriteLine(string.Join("|", array));
			Console.WriteLine(array.Sum());
		}
	}
}
