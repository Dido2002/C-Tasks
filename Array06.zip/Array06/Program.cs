﻿using System;
using System.Linq;
using System.Runtime.Intrinsics.Arm;
using System.Security;
using System.Transactions;

namespace Array06
{
	internal class Program
	{
		static void Main(string[] args)
		{

			//My Way To Solve The Problem

			//Console.WriteLine("How many numbers you want to add in the array?");
			//int count = int.Parse(Console.ReadLine());
			//int[] numbers = new int[count];	
			//int sumEven = 0; 
			//int sumOdd = 0;

			//for (int i = 0; i < numbers.Length; i++)
			//{	
			//	int currentNumber = int.Parse(Console.ReadLine());
			//	if (currentNumber % 2 == 0)
			//	{
			//		sumEven += currentNumber;
			//	}
			//	else 
			//	{
			//		sumOdd += currentNumber;	
			//	}
			//}
			//int difference = Math.Abs(sumOdd - sumEven);
			//Console.WriteLine($"The sum of the evens is: {sumEven}");
			//Console.WriteLine($"The sum of the odds is: {sumOdd}");
			//Console.WriteLine($"The difference is: {difference}");



			//Other Way To Solve The Problem
			Console.WriteLine("Input numbers in the array!");
			int[] array = Console.ReadLine().Split(' ').Select(int.Parse).ToArray();	
			int sumOdds = 0;	
			int sumEvens = 0;
			int difference = 0;
			for (int i = 0; i < array.Length; i++)
			{
				int currentNum = array[i];
				if (currentNum % 2 == 0)
				{
					sumEvens += currentNum;
				}
				else 
				{
					sumOdds += currentNum;	
				}
			}
			difference = Math.Abs(sumEvens - sumOdds);
			Console.WriteLine($"The sum of the evens is {sumEvens}");
			Console.WriteLine($"The sum of the odds is {sumOdds}");
			Console.WriteLine($"The difference is {difference}");

		}
	}
}
