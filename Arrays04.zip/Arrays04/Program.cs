﻿using System;
using System.Linq;
using System.Threading.Tasks.Dataflow;

namespace Arrays04
{
	internal class Program
	{
		static void Main(string[] args)
		{
			string[] items = Console.ReadLine().Split();
			
			Array.Reverse(items);
			Console.WriteLine(string.Join(" ", items));
		

		}
	}
}
