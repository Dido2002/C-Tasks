﻿using System;
using System.Linq;
using System.Net;
using System.Reflection.Emit;

namespace ArraysEx04
{
	internal class Program
	{
		static void Main(string[] args)
		{
			//First we create an array then we create a variable swapCount to check how many elements in the array we want to rotate
			int[] array = Console.ReadLine().Split(' ').Select(int.Parse).ToArray();
			int swapCount = int.Parse(Console.ReadLine());

			//Add a for loop for the number of the slaps we want to do
			for (int i = 0; i < swapCount; i++)
			{
				int temp = array[0];
				for (int operations = 0; operations < array.Length - 1; operations++)
				{
					array[operations] = array[operations + 1];
				}
				array[array.Length - 1] = temp;
			}
			Console.WriteLine(string.Join(" ",array));
		}

	}
}
