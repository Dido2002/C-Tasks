﻿using System;
using System.Linq;

namespace Array05
{
	internal class Program
	{
		static void Main(string[] args)
		{
			//My Way To Solve The Problem

			//Console.WriteLine("How many numbers you want to add?");
			//int count = int.Parse(Console.ReadLine());
			//int[] array = new int[count];
			//int sum = 0;

			//for (int i = 0; i < count; i++)
			//{
			//	int current = int.Parse(Console.ReadLine());
			//	array[i] = current;
			//	if (current % 2 == 0) 
			//	{
			//		sum += current;
			//	}
			//}


			//Console.WriteLine(sum);


			//Other Way To Solve The Problem
			Console.WriteLine("Input numbers in the array!");
			int sum = 0;
			int[] array = Console.ReadLine()
				.Split(' ')
				.Select(int.Parse)
				.ToArray();
			for (int i = 0; i < array.Length; i++)
			{
				int currentNumber = array[i];
				if (currentNumber % 2 == 0) 
				{
					sum += currentNumber;
				}
			}
			Console.WriteLine($"The sum of the evens is:{sum}");

		}
	}
}
